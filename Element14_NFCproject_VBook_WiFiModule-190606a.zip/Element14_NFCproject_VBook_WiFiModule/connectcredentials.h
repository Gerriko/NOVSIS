#define SECRET_SSID ""
#define SECRET_PASS ""
#define FIREBASE_HOST ""
#define FIREBASE_AUTH ""
