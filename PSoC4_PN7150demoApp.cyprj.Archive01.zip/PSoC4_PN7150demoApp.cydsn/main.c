/*****************************************************************************
* File Name: main.c
*
* Version: 1.00
*
* Description: 
*

*
* Disclaimer: THIS SOFTWARE IS PROVIDED AS-IS, WITH NO WARRANTY OF ANY KIND, 
* EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT, IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. Cypress 
* reserves the right to make changes to the Software without notice. Cypress 
* does not assume any liability arising out of the application or use of the 
* Software or any product or circuit described in the Software. Cypress does 
* not authorize its products for use in any products where a malfunction or 
* failure of the Cypress product may reasonably be expected to result in 
* significant property damage, injury or death (“High Risk Product”). By 
* including Cypress’s product in a High Risk Product, the manufacturer of such 
* system or application assumes all risk of such use and in doing so agrees to 
* indemnify Cypress against all liability. 
*******************************************************************************/

#include <project.h>
#include <stdio.h>

#include <app_common.h>
#include <tml.h>
#include <ndef_helper.h>
#include <Nfc.h>
#include <NxpNci.h>
#include <ble.h>

/***************************************
*        Function Prototypes
***************************************/
uint8_t Establish_UART_Comms(void);
uint8_t Establish_WIFI_Comms(void);
_Bool Check_UART_OK(void);
_Bool WaitFor_UART_VcardToken(void);


void NdefPull_Cb(unsigned char *pNdefMessage, unsigned short NdefMessageSize);
void NdefPush_Cb(unsigned char *pNdefRecord, unsigned short NdefRecordSize);
void displayCardInfo(NxpNci_RfIntf_t RfIntf);
void task_nfc_reader(NxpNci_RfIntf_t RfIntf);
void task_nfc(void);

/*******************************************************************************
* GLOBAL CONSTANTS
********************************************************************************/

const uint32_t CHECKWIFIMODULEEXISTS = 3000;
const uint32_t WAITFORTOKENRESPONSE = 30000;

/*******************************************************************************
* GLOBAL VARIABLES
********************************************************************************/

uint8_t errorStatus = 0u;
uint8_t WiFiModuleMode = 0u;                // 0 = unknown
uint8_t VcardMode = 0u;                     // 0 = unknown
uint8_t AccessTokenReceived[16] = {'\0'};
_Bool WiFiDataTransferred = false;
_Bool activateBLE = false;

char * localBLEName;

/* Discovery loop configuration according to the targeted modes of operation */
unsigned char DiscoveryTechnologies[] = {
#if defined P2P_SUPPORT || defined RW_SUPPORT
    MODE_POLL | TECH_PASSIVE_NFCA,
    MODE_POLL | TECH_PASSIVE_NFCF,
#endif // if defined P2P_SUPPORT || defined RW_SUPPORT
#ifdef RW_SUPPORT
    MODE_POLL | TECH_PASSIVE_NFCB,
    MODE_POLL | TECH_PASSIVE_15693,
#endif // ifdef RW_SUPPORT
#ifdef P2P_SUPPORT
    /* Only one POLL ACTIVE mode can be enabled, if both are defined only NFCF applies */
    MODE_POLL | TECH_ACTIVE_NFCA,
    //MODE_POLL | TECH_ACTIVE_NFCF,
#endif // ifdef P2P_SUPPORT
#if defined P2P_SUPPORT || defined CARDEMU_SUPPORT
    MODE_LISTEN | TECH_PASSIVE_NFCA,
#endif // if defined P2P_SUPPORT || defined CARDEMU_SUPPORT
#if defined CARDEMU_SUPPORT
    MODE_LISTEN | TECH_PASSIVE_NFCB,
#endif // if defined CARDEMU_SUPPORT
#ifdef P2P_SUPPORT
    MODE_LISTEN | TECH_PASSIVE_NFCF,
    MODE_LISTEN | TECH_ACTIVE_NFCA,
    MODE_LISTEN | TECH_ACTIVE_NFCF,
#endif // ifdef P2P_SUPPORT
};

/* Mode configuration according to the targeted modes of operation */
unsigned mode = 0
#ifdef CARDEMU_SUPPORT 
    | NXPNCI_MODE_CARDEMU
#endif // ifdef P2P_SUPPORT
#ifdef P2P_SUPPORT 
    | NXPNCI_MODE_P2P
#endif // ifdef CARDEMU_SUPPORT
#ifdef RW_SUPPORT 
    | NXPNCI_MODE_RW
#endif // ifdef RW_SUPPORT
;

/*******************************************************************************
* ISR Interrupts and Handlers
********************************************************************************/

/* Interrupt prototypes */
CY_ISR_PROTO(NxpNci_PinIRQ_Handler);


/* Add an explicit reference to the floating point printf library to allow
the usage of floating point conversion specifier */
#if defined (__GNUC__)
    asm (".global _printf_float");
#endif


/*******************************************************************************
* ISR Function Name: RxIsr
********************************************************************************
*
* Summary:
*  Interrupt Service Routine for RX portion of the UART
*
* Parameters:
*  None.
*
* Return:
*  None.
*
*******************************************************************************/
CY_ISR(RxIsr)
{
    uint8 rxStatus;         
    uint8 rxData;           
    
    do
    {
        /* Read receiver status register */
        rxStatus = UART_DEBUG_RXSTATUS_REG;

        if((rxStatus & (UART_DEBUG_RX_STS_BREAK      | UART_DEBUG_RX_STS_PAR_ERROR |
                        UART_DEBUG_RX_STS_STOP_ERROR | UART_DEBUG_RX_STS_OVERRUN)) != 0u)
        {
            /* ERROR handling. */
            errorStatus |= rxStatus & ( UART_DEBUG_RX_STS_BREAK      | UART_DEBUG_RX_STS_PAR_ERROR | 
                                        UART_DEBUG_RX_STS_STOP_ERROR | UART_DEBUG_RX_STS_OVERRUN);
        }
        
        if((rxStatus & UART_DEBUG_RX_STS_FIFO_NOTEMPTY) != 0u)
        {
            /* Read data from the RX data register */
            rxData = UART_DEBUG_RXDATA_REG;
            if(errorStatus == 0u)
            {
                /* Send data backward */
                UART_DEBUG_TXDATA_REG = rxData;
            }
        }
    }while((rxStatus & UART_DEBUG_RX_STS_FIFO_NOTEMPTY) != 0u);

}


/*******************************************************************************
* ISR Function Name: NxpNci_PinIRQ_Handler
********************************************************************************
* Summary:
*  The interrupt handler for GPIO Pin_IRQ interrupts.
*  Clears a pending Interrupt.
*  Clears a pin Interrupt.
*  Blinks the LED with the LED_Isr pin.

*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
CY_ISR(NxpNci_PinIRQ_Handler)
{
    /* Clear pending Interrupt */
    isr_IRQ_ClearPending();
    
    /* Clear pin Interrupt */
    Pin_IRQ_ClearInterrupt();
    
}

/*******************************************************************************
* Function Name: Establish_UART_Comms
********************************************************************************
* Summary:
*  This uses the WIFI UART Block
*  Waits untils it reads an 'e'
*  then sends a CR/LF
*  Then sends a '1' and a '4' as a response
*
* Parameters:
*  None
*
* Return:
*  UART Mode
*
*******************************************************************************/
uint8_t Establish_UART_Comms(void)
{
    uint32_t Cntr = 0;
    uint8_t rxStatus = 0;
    uint8_t rxData = 0;
    uint8_t i,j,x;
    uint8_t UARTMode = 0;
    char UARTChar = 'e';
    
    for (x = 0; x < 2; x++) {
        /* Read to see if any bytes available in the RX buffer. */
        do {
            rxStatus = UART_WIFI_SpiUartGetRxBufferSize();
            if (rxStatus > 0) {
                for (i = 0; i < rxStatus; i++) {
                    /* Read received byte */
                    rxData = UART_WIFI_UartGetChar();
                    if (rxData > 30 && rxData < 127) {
                        //DBG_PRINTF("%c", rxData);
                        if (rxData == UARTChar) {
                            DBG_PRINTF("\r\nReceived the UART response after %d chars\r\n", i+1);
                            if (!x) {
                                for (j = 0; j < 3; j++) {
                                    // Now send some data in return
                                    UART_WIFI_UartPutChar('1');
                                    UART_WIFI_UartPutCRLF('4');
                                    CyDelay(1);
                                }
                            }
                            break;
                        }
                    }
                }
                // If we received the 'e' let's check for the confirmation 'c'
                if (!x) {
                    if (rxData == UARTChar) {
                        Cntr = 0;
                        UARTMode = 1;
                        UARTChar = 'c';
                        break;
                    }
                    else rxData = 0;
                }
                else {
                    if (rxData == UARTChar) {
                        UARTMode = 2;
                        break;
                    }
                }
            }
            Cntr++;
            CyDelay(1);
        } while ((Cntr <= CHECKWIFIMODULEEXISTS));
        if (!rxData) break;
    }
    return UARTMode;
}

/*******************************************************************************
* Function Name: Establish_WIFI_Comms
********************************************************************************
* Summary:
*  This uses the WIFI UART Block
*  Waits untils it reads a 'w' or a 'v'
*
* Parameters:
*  None
*
* Return:
*  WiFi Mode
*
*******************************************************************************/
uint8_t Establish_WIFI_Comms(void)
{
    uint32_t Cntr = 0;
    uint8_t rxStatus = 0;
    uint8_t rxData;
    uint8_t i;
    uint8_t WiFiMode = 0;
        
    // Now wait for status confirmation and info about whether Module has WiFi credentials or is ready for vCard details
    do {
        rxStatus = UART_WIFI_SpiUartGetRxBufferSize();
        if (rxStatus > 0) {
            for (i = 0; i < rxStatus; i++) {
                /* Read received byte */
                rxData = UART_WIFI_UartGetChar();
                if (rxData > 30 && rxData < 127) {
                    //DBG_PRINTF("%c", rxData);
                    if (rxData == 'w') {
                        DBG_PRINTF("\r\nReceived the WIFI response after %d chars\r\n", i+1);
                        WiFiMode = 3;
                        UART_WIFI_SpiUartClearRxBuffer();
                        break;
                    }
                    else if (rxData == 'v') {
                        DBG_PRINTF("\r\nReceived the vCard response after %d chars\r\n", i+1);
                        WiFiMode = 4;
                        UART_WIFI_SpiUartClearRxBuffer();
                        break;
                    }
                }
            }
            if (WiFiMode) break;
        }
        Cntr++;
        CyDelay(1);
    } while (Cntr <= CHECKWIFIMODULEEXISTS);
            
    
    return WiFiMode;
}

/*******************************************************************************
* Function Name: Check_UART_OK
********************************************************************************
* Summary:
* Parameters:
*  None
*
* Return:
*  true or false
*
*******************************************************************************/
_Bool Check_UART_OK(void)
{
    uint8_t rxStatus = UART_WIFI_SpiUartGetRxBufferSize();
    uint8_t rxData;
    char UARTChar[3] = {'e', 'w', 'v'};
    _Bool newUpdate = true;

    if (rxStatus) {
        for (uint8_t i = 0; i < rxStatus; i++) {
            /* Read received byte */
            rxData = UART_WIFI_UartGetChar();
            if (rxData == UARTChar[0]) {
                // Looks like UART module has rebooted for some reason
                // Update the global variable to reflect change in WIFI status
                WiFiModuleMode = 0;
                newUpdate = false;
                break;
            }
            else if (rxData == UARTChar[1]) {
                // Looks like we still require WiFi details
                WiFiModuleMode = 3;
                newUpdate = true;
            }
            else if (rxData == UARTChar[2]) {
                // Looks like we onto vCards
                WiFiModuleMode = 4;
                newUpdate = false;
            }
        }
    }
    return newUpdate;
}

/*******************************************************************************
* Function Name: WaitFor_UART_VcardToken
********************************************************************************
* Summary:
*  This uses the WIFI UART Block
*  Waits untils it receives a vCard Token
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
_Bool WaitFor_UART_VcardToken(void)
{
    uint8_t tknCntr = 0;
    uint32_t Cntr = 0;
    uint8_t rxStatus = 0;
    uint8_t rxData;
    uint8_t i;
    _Bool TokenFound = false;
        
    DBG_PRINTF("--- We've reached the VcardToken Check. Waiting for New Token! \r\n");
    memset(AccessTokenReceived, '\0', 16);
    
    // Now wait for status confirmation and info about whether Module has WiFi credentials or is ready for vCard details
    do {
        rxStatus = UART_WIFI_SpiUartGetRxBufferSize();
        if (rxStatus > 0) {
            for (i = 0; i < rxStatus; i++) {
                /* Read received byte */
                rxData = UART_WIFI_UartGetChar();
                if (rxData > 30 && rxData < 127) {
                    DBG_PRINTF("%c", rxData);
                    if (tknCntr < 16) {
                        AccessTokenReceived[tknCntr] = rxData;
                        tknCntr++;
                    }
                }
                else {
                    DBG_PRINTF("0x%02X-", rxData);
                    if (rxData == 0x9E) {
                        if (tknCntr == 16) {
                            DBG_PRINTF("\r\n A Valid Token Received: ");
                            for (i = 0; i < 16; i++) {
                                DBG_PRINTF("%02X", AccessTokenReceived[i]);
                            }
                            DBG_PRINTF("\r\n\r\n ** NOW READY TO WRITE TOKEN TO A MIFARE CARD **\r\n");
                            TokenFound = true;
                            break;
                        }
                        else {
                            DBG_PRINTF("\r\n Sorry, Token Received Corrupted\r\n");
                        }
                    }
                }
            }
        }
        Cntr++;
        CyDelay(1);
    } while (Cntr <= WAITFORTOKENRESPONSE);
    DBG_PRINTF("\r\n");
    if (TokenFound) VcardMode = 2;                  // This now allows us to write the token to a MIFARE card
    else VcardMode = 0;                             // We reset the VcardMode
    return true;
}

/*******************************************************************************
* NFC FUNCTIONS
********************************************************************************/

#if defined P2P_SUPPORT || defined RW_SUPPORT
void NdefPull_Cb(unsigned char *pNdefMessage, unsigned short NdefMessageSize)
{
    unsigned char *pNdefRecord = pNdefMessage;
    NdefRecord_t NdefRecord;
    unsigned char save;

    if (pNdefMessage == NULL)
    {
        DBG_PRINTF("--- Provisioned buffer size too small or NDEF message empty \r\n");
        return;
    }

    while (pNdefRecord != NULL)
    {
        DBG_PRINTF("--- NDEF record received:\r\n");

        NdefRecord = DetectNdefRecordType(pNdefRecord);

        switch(NdefRecord.recordType)
        {
        case MEDIA_VCARD:
            {
                save = NdefRecord.recordPayload[NdefRecord.recordPayloadSize];
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = '\0';
                DBG_PRINTF("0x%02X   vCard:\r\n%s\r\n", NdefRecord.recordType, NdefRecord.recordPayload);
                if (WiFiModuleMode == 4) {
                    UART_WIFI_UartPutChar('v');
                    UART_WIFI_UartPutCRLF(NdefRecord.recordType);
                    UART_WIFI_UartPutString((const char*)NdefRecord.recordPayload);
                    UART_WIFI_UartPutCRLF(0xC7);
                    /* Now turn OFF the Red LED to show data read and transmitted*/
                    LED_Red_Write(LED_OFF);
                    VcardMode = 1;                  // We set this to say we have sent off a Vcard
                }
                
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = save;
            }
            break;

        case WELL_KNOWN_SIMPLE_TEXT:
            {
                save = NdefRecord.recordPayload[NdefRecord.recordPayloadSize];
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = '\0';
                DBG_PRINTF("0x%02X   Text record: %s\r\n", NdefRecord.recordType, &NdefRecord.recordPayload[NdefRecord.recordPayload[0]+1]);
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = save;
                /* Now turn OFF the Red LED to show data read and transmitted*/
                LED_Red_Write(LED_OFF);
            }
            break;

        case WELL_KNOWN_SIMPLE_URI:
            {
                save = NdefRecord.recordPayload[NdefRecord.recordPayloadSize];
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = '\0';
                DBG_PRINTF("   URI record: %s%s\r\n", ndef_helper_UriHead(NdefRecord.recordPayload[0]), &NdefRecord.recordPayload[1]);
                NdefRecord.recordPayload[NdefRecord.recordPayloadSize] = save;
                /* Now turn OFF the Red LED to show data read and transmitted*/
                LED_Red_Write(LED_OFF);
            }
            break;

        case MEDIA_HANDOVER_WIFI:
            {
                unsigned char index = 0, i;
                
                DBG_PRINTF ("0x%02X --- Received WIFI credentials (%d):\r\n", NdefRecord.recordType, WiFiModuleMode);
                if ((NdefRecord.recordPayload[index] == 0x10) && (NdefRecord.recordPayload[index+1] == 0x0e)) index+= 4;
                while(index < NdefRecord.recordPayloadSize)
                {
                    if (NdefRecord.recordPayload[index] == 0x10)
                    {
                        if (NdefRecord.recordPayload[index+1] == 0x45) {
                            // First send to UART message type
                            if (WiFiModuleMode == 3) {
                                UART_WIFI_UartPutChar('w');
                                UART_WIFI_UartPutCRLF(NdefRecord.recordType);
                            }
                            DBG_PRINTF ("- SSID = "); 
                            for(i=0;i<NdefRecord.recordPayload[index+3];i++) {
                                DBG_PRINTF("%c", NdefRecord.recordPayload[index+4+i]);
                                if (WiFiModuleMode == 3) {
                                    // We send SSID data via UART followed by the '+' char
                                    UART_WIFI_UartPutChar(NdefRecord.recordPayload[index+4+i]);
                                }
                            }
                            DBG_PRINTF ("\r\n");
                            if (WiFiModuleMode == 3) UART_WIFI_UartPutChar('+');
                        }
                        else if (NdefRecord.recordPayload[index+1] == 0x03) DBG_PRINTF ("- Authenticate Type = %s\r\n", ndef_helper_WifiAuth(NdefRecord.recordPayload[index+5]));
                        else if (NdefRecord.recordPayload[index+1] == 0x0f) DBG_PRINTF ("- Encryption Type = %s\r\n", ndef_helper_WifiEnc(NdefRecord.recordPayload[index+5]));
                        else if (NdefRecord.recordPayload[index+1] == 0x27) {
                            DBG_PRINTF ("- Network key = "); 
                            for(i=0;i<NdefRecord.recordPayload[index+3];i++) {
                                DBG_PRINTF("#"); //DBG_PRINTF("%c", NdefRecord.recordPayload[index+4+i]);
                                if (WiFiModuleMode == 3) {
                                    // We send SSID data via UART followed by the '+' char
                                    UART_WIFI_UartPutChar(NdefRecord.recordPayload[index+4+i]);
                                }
                            }
                            DBG_PRINTF ("\r\n");
                            
                            if (WiFiModuleMode == 3) {
                                UART_WIFI_UartPutCRLF(0xC7);               // Send bespoke command byte to say complete
                                WiFiDataTransferred = true;
                                /* Now turn OFF the Red LED to show data read and transmitted*/
                                LED_Red_Write(LED_OFF);
                            }
                        }
                        index += 4 + NdefRecord.recordPayload[index+3];
                    }
                    else continue;
                }
                
            }
            break;

        case WELL_KNOWN_HANDOVER_SELECT:
            DBG_PRINTF("   Handover select version %d.%d\r\n", NdefRecord.recordPayload[0] >> 4, NdefRecord.recordPayload[0] & 0xF);
            break;

        case WELL_KNOWN_HANDOVER_REQUEST:
            DBG_PRINTF("   Handover request version %d.%d\r\n", NdefRecord.recordPayload[0] >> 4, NdefRecord.recordPayload[0] & 0xF);
            break;

        case MEDIA_HANDOVER_BT:
            print_buf("   BT Handover payload = ", NdefRecord.recordPayload, NdefRecord.recordPayloadSize);
            break;

        case MEDIA_HANDOVER_BLE:
            print_buf("   BLE Handover payload = ", NdefRecord.recordPayload, NdefRecord.recordPayloadSize);
            break;

        case MEDIA_HANDOVER_BLE_SECURE:
            print_buf("   BLE secure Handover payload = ", NdefRecord.recordPayload, NdefRecord.recordPayloadSize);
            break;

        default:
            DBG_PRINTF("   Unsupported NDEF record, cannot parse\r\n");
            break;
        }
        pNdefRecord = GetNextRecord(pNdefRecord);
    }

    DBG_PRINTF("\r\n");
}
#endif // if defined P2P_SUPPORT || defined RW_SUPPORT

#if defined P2P_SUPPORT || defined CARDEMU_SUPPORT
const char NDEF_MESSAGE[] = { 0xD1,   // MB/ME/CF/1/IL/TNF
        0x01,   // TYPE LENGTH
        0x1C,   // PAYLOAD LENTGH (28)
        'T',    // TYPE
        0x02,   // Status
        'e', 'n', // Language
        'B', 'L', 'E', ' ', 'V', 'c', 'a', 'r', 'd', 's',                   // BLE Device Name
        '~', '0', '0', '0', '9', '0', '0', '0', '0',                        // BLE Service UUID (part of)
        '~', 'V', 'C', '2', '.', '1'};                                      // VCard version number

void NdefPush_Cb(unsigned char *pNdefRecord, unsigned short NdefRecordSize) 
{
    DBG_PRINTF("--- NDEF Record sent\r\n\r\n");
    
    // Set the flag to activate BLE module
    activateBLE = true;
    
    // Turn off Red LED and leave Green LED on to show successful transfer
    LED_Red_Write(LED_OFF);
    
}
#endif // if defined P2P_SUPPORT || defined CARDEMU_SUPPORT

#if defined RW_SUPPORT
#ifdef RW_RAW_EXCHANGE
void PCD_MIFARE_scenario (void)
{
    #define BLK_NB_MFC      4
    #define KEY_MFC         0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF
    #define DATA_WRITE_MFC  0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, 0x88, 0x99, 0xaa, 0xbb, 0xcc, 0xdd, 0xee, 0xff

    _Bool status;
    unsigned char Resp[256];
    unsigned char RespSize;
    /* Authenticate sector 1 with generic keys */
    unsigned char Auth[] = {0x40, BLK_NB_MFC/4, 0x10, KEY_MFC};
    /* Read block 4 */
    unsigned char Read[] = {0x10, 0x30, BLK_NB_MFC};
    /* Write block 4 */
    unsigned char WritePart1[] = {0x10, 0xA0, BLK_NB_MFC};
    unsigned char WritePart2[] = {0x10, DATA_WRITE_MFC};

    /* Authenticate */
    status = NxpNci_ReaderTagCmd(Auth, sizeof(Auth), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Authenticate sector %d failed with error 0x%02x\r\n", Auth[1], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Authenticate sector %d succeed\r\n", Auth[1]);

    /* Read block */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Read block %d failed with error 0x%02x\r\n", Read[2], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Read block %d:", Read[2]); print_buf(" ", (Resp+1), RespSize-2);

    /* Write block */
    status = NxpNci_ReaderTagCmd(WritePart1, sizeof(WritePart1), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Write block %d failed with error 0x%02x\r\n", WritePart1[2], Resp[RespSize-1]);
        return;
    }
    status = NxpNci_ReaderTagCmd(WritePart2, sizeof(WritePart2), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Write block %d failed with error 0x%02x\r\n", WritePart1[2], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Block %d written\r\n", WritePart1[2]);

    /* Read block */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Read failed with error 0x%02x\r\n", Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Read block %d:", Read[2]); print_buf(" ", (Resp+1), RespSize-2);
}

void PCD_ISO15693_scenario (void)
{
    #define BLK_NB_ISO15693     8
    #define DATA_WRITE_ISO15693 0x11, 0x22, 0x33, 0x44

    _Bool status;
    unsigned char Resp[256];
    unsigned char RespSize;
    unsigned char ReadBlock[] = {0x02, 0x20, BLK_NB_ISO15693};
    unsigned char WriteBlock[] = {0x02, 0x21, BLK_NB_ISO15693, DATA_WRITE_ISO15693};

    status = NxpNci_ReaderTagCmd(ReadBlock, sizeof(ReadBlock), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0x00))
    {
        DBG_PRINTF(" Read block %d failed with error 0x%02x\r\n", ReadBlock[2], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Read block %d:", ReadBlock[2]); print_buf(" ", (Resp+1), RespSize-2);

    /* Write */
    status = NxpNci_ReaderTagCmd(WriteBlock, sizeof(WriteBlock), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Write block %d failed with error 0x%02x\r\n", WriteBlock[2], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Block %d written\r\n", WriteBlock[2]);

    /* Read back */
    status = NxpNci_ReaderTagCmd(ReadBlock, sizeof(ReadBlock), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0x00))
    {
        DBG_PRINTF(" Read block %d failed with error 0x%02x\r\n", ReadBlock[2], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Read block %d:", ReadBlock[2]); print_buf(" ", (Resp+1), RespSize-2);
}

void PCD_ISO14443_3A_scenario (void)
{
    #define BLK_NB_ISO14443_3A      5
    #define DATA_WRITE_ISO14443_3A  0x11, 0x22, 0x33, 0x44

    _Bool status;
    unsigned char Resp[256];
    unsigned char RespSize;
    /* Read block */
    unsigned char Read[] = {0x30, BLK_NB_ISO14443_3A};
    /* Write block */
    unsigned char Write[] = {0xA2, BLK_NB_ISO14443_3A, DATA_WRITE_ISO14443_3A};
    
    /* Read */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Read block %d failed with error 0x%02x\r\n", Read[1], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Read block %d:", Read[1]); print_buf(" ", Resp, 4);
    /* Write */
    status = NxpNci_ReaderTagCmd(Write, sizeof(Write), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Write block %d failed with error 0x%02x\r\n", Write[1], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Block %d written\r\n", Write[1]);

    /* Read back */
    status = NxpNci_ReaderTagCmd(Read, sizeof(Read), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-1] != 0))
    {
        DBG_PRINTF(" Read block %d failed with error 0x%02x\r\n", Read[1], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Read block %d:", Read[1]); print_buf(" ", Resp, 4);
}

void PCD_ISO14443_4_scenario (void)
{
    _Bool status;
    unsigned char Resp[256];
    unsigned char RespSize;
    unsigned char SelectPPSE[] = {0x00, 0xA4, 0x04, 0x00, 0x0E, 0x32, 0x50, 0x41, 0x59, 0x2E, 0x53, 0x59, 0x53, 0x2E, 0x44, 0x44, 0x46, 0x30, 0x31, 0x00};

    status = NxpNci_ReaderTagCmd(SelectPPSE, sizeof(SelectPPSE), Resp, &RespSize);
    if((status == NFC_ERROR) || (Resp[RespSize-2] != 0x90) || (Resp[RespSize-1] != 0x00))
    {
        DBG_PRINTF(" Select PPSE failed with error %02x %02x\r\n", Resp[RespSize-2], Resp[RespSize-1]);
        return;
    }
    DBG_PRINTF(" Select NDEF Application succeed\r\n");
}

#endif // ifdef RW_RAW_EXCHANGE

void displayCardInfo(NxpNci_RfIntf_t RfIntf)
{
    /* Turn On the Read Reject LED for all cases*/
    LED_Red_Write(LED_ON);
    switch(RfIntf.Protocol){
    case PROT_T2T:
        DBG_PRINTF(" - POLL MODE: Remote T%dT activated\r\n", RfIntf.Protocol);
        /* Turn On the Grren Read OK LED - this results on yellow*/
        LED_Green_Write(LED_ON);
        break;
    case PROT_T1T:
    case PROT_T3T:
    case PROT_ISODEP:
        DBG_PRINTF(" - POLL MODE: Remote T%dT activated\r\n", RfIntf.Protocol);
        break;
    case PROT_ISO15693:
        DBG_PRINTF(" - POLL MODE: Remote ISO15693 card activated\r\n");
        break;
    case PROT_MIFARE:
        DBG_PRINTF(" - POLL MODE: Remote MIFARE card activated\r\n");
        // Now we can activate this when ready to read/write data etc.
        
        
        break;
    default:
        DBG_PRINTF(" - POLL MODE: Undetermined target\r\n");
        return;
    }

    switch(RfIntf.ModeTech) {
    case (MODE_POLL | TECH_PASSIVE_NFCA):
        DBG_PRINTF("\tSENS_RES = 0x%.2x 0x%.2x\r\n", RfIntf.Info.NFC_APP.SensRes[0], RfIntf.Info.NFC_APP.SensRes[1]);
        print_buf("\tNFCID = ", RfIntf.Info.NFC_APP.NfcId, RfIntf.Info.NFC_APP.NfcIdLen);
        if(RfIntf.Info.NFC_APP.SelResLen != 0) DBG_PRINTF("\tSEL_RES = 0x%.2x\r\n", RfIntf.Info.NFC_APP.SelRes[0]);
    break;

    case (MODE_POLL | TECH_PASSIVE_NFCB):
        if(RfIntf.Info.NFC_BPP.SensResLen != 0) print_buf("\tSENS_RES = ", RfIntf.Info.NFC_BPP.SensRes, RfIntf.Info.NFC_BPP.SensResLen);
    break;

    case (MODE_POLL | TECH_PASSIVE_NFCF):
        DBG_PRINTF("\tBitrate = %s\r\n", (RfIntf.Info.NFC_FPP.BitRate==1)?"212":"424");
        if(RfIntf.Info.NFC_FPP.SensResLen != 0) print_buf("\tSENS_RES = ", RfIntf.Info.NFC_FPP.SensRes, RfIntf.Info.NFC_FPP.SensResLen);
    break;

    case (MODE_POLL | TECH_PASSIVE_15693):
        print_buf("\tID = ", RfIntf.Info.NFC_VPP.ID, sizeof(RfIntf.Info.NFC_VPP.ID));
        DBG_PRINTF("\tAFI = 0x%.2x\r\n", RfIntf.Info.NFC_VPP.AFI);
        DBG_PRINTF("\tDSFID = 0x%.2x\r\n", RfIntf.Info.NFC_VPP.DSFID);
    break;

    default:
        break;
    }
}

void task_nfc_reader(NxpNci_RfIntf_t RfIntf)
{
    /* For each discovered cards */
    while(1){
        /* Display detected card information */
        displayCardInfo(RfIntf);

        /* What's the detected card type ? */
        switch(RfIntf.Protocol) {
        // Here we only want to process Tag Type 2
            
        case PROT_T1T:
        case PROT_T3T:
        case PROT_ISODEP:
        break;
        case PROT_T2T:
//#ifndef RW_RAW_EXCHANGE
            /* Process NDEF message read */
            NxpNci_ProcessReaderMode(RfIntf, READ_NDEF);

// The Alternative to using P2P is defining the option
#ifdef RW_NDEF_WRITING
            RW_NDEF_SetMessage ((unsigned char *) NDEF_MESSAGE, sizeof(NDEF_MESSAGE), *NdefPush_Cb);
            /* Process NDEF message write */
            NxpNci_ReaderReActivate(&RfIntf);
            NxpNci_ProcessReaderMode(RfIntf, WRITE_NDEF);
#endif // RW_NDEF_WRITING


//#else // ifndef RW_RAW_EXCHANGE
//            if (RfIntf.Protocol == PROT_ISODEP)
//            {
//                PCD_ISO14443_4_scenario();
//            }
//            else if (RfIntf.Protocol == PROT_T2T)
//            {
//                PCD_ISO14443_3A_scenario();
//            }
//#endif // ifndef RW_RAW_EXCHANGE
            break;

        case PROT_ISO15693:
//#ifdef RW_RAW_EXCHANGE
            /* Run dedicated scenario to demonstrate ISO15693 card management */
//            PCD_ISO15693_scenario();
//#endif // ifdef RW_RAW_EXCHANGE
            break;

        case PROT_MIFARE:
#ifdef RW_RAW_EXCHANGE
            /* Run dedicated scenario to demonstrate MIFARE card management */
            // This only applies if we have sent the vCard and have received the tokem
            // ************** TODO
            LED_Green_Write(LED_ON);
            PCD_MIFARE_scenario();
#endif // ifdef RW_RAW_EXCHANGE
            break;

        default:
            break;
        }

        /* If more cards (or multi-protocol card) were discovered (only same technology are supported) select next one */
        if(RfIntf.MoreTags) {
            if(NxpNci_ReaderActivateNext(&RfIntf) == NFC_ERROR) break;
        }
        /* Otherwise leave */
        else break;
    }

    /* Wait for card removal */
    NxpNci_ProcessReaderMode(RfIntf, PRESENCE_CHECK);

    DBG_PRINTF("CARD REMOVED\r\n");
    
    LED_Green_Write(LED_OFF);
    LED_Red_Write(LED_OFF);

    /* Restart discovery loop */
    // NOTE THERE IS NO PROPER ERROR HANDLING HERE
    if (NxpNci_StopDiscovery()) DBG_PRINTF("Discovery Stop Error\r\n");
    if (NxpNci_StartDiscovery(DiscoveryTechnologies,sizeof(DiscoveryTechnologies))) {
        // try again
        DBG_PRINTF("Discovery Start Error - trying again\r\n");
        CyDelay(50);
        if (NxpNci_StartDiscovery(DiscoveryTechnologies,sizeof(DiscoveryTechnologies))) 
            DBG_PRINTF("Discovery Start Error\r\n");
    }
}
#endif // if defined RW_SUPPORT

#ifdef CARDEMU_SUPPORT
#ifdef CARDEMU_RAW_EXCHANGE
void PICC_ISO14443_4_scenario (void)
{
    unsigned char OK[] = {0x90, 0x00};
    unsigned char Cmd[256];
    unsigned char CmdSize;

    while (1)
    {
        if(NxpNci_CardModeReceive(Cmd, &CmdSize) == NFC_SUCCESS)
        {
            if ((CmdSize >= 2) && (Cmd[0] == 0x00))
            {
            	switch (Cmd[1])
            	{
            	case 0xA4:
            		DBG_PRINTF("Select File received\r\n");
            		break;

            	case 0xB0:
            		DBG_PRINTF("Read Binary received\r\n");
            		break;

            	case 0xD0:
                	DBG_PRINTF("Write Binary received\r\n");
            		break;

            	default:
            		break;
            	}

                NxpNci_CardModeSend(OK, sizeof(OK));
            }
        }
        else
        {
            DBG_PRINTF("End of transaction\r\n");
            return;
        }
    }
}
#endif // if defined CARDEMU_RAW_EXCHANGE
#endif // if defined CARDEMU_SUPPORT


/*******************************************************************************
* Function Name: task_nfc
********************************************************************************
*
* Summary:
*   Handles the PN7150 tasks.
*
*******************************************************************************/


void task_nfc(void)
{
    NxpNci_RfIntf_t RfInterface;

    #ifdef CARDEMU_SUPPORT
    /* Register NDEF message to be sent to remote reader */
    T4T_NDEF_EMU_SetMessage((unsigned char *) NDEF_MESSAGE, sizeof(NDEF_MESSAGE), *NdefPush_Cb);
    #endif // if defined CARDEMU_SUPPORT

    #ifdef P2P_SUPPORT
    /* Register NDEF message to be sent to remote peer */
    P2P_NDEF_SetMessage((unsigned char *) NDEF_MESSAGE, sizeof(NDEF_MESSAGE), *NdefPush_Cb);
    /* Register callback for reception of NDEF message from remote peer */
    P2P_NDEF_RegisterPullCallback(*NdefPull_Cb);
    #endif // if defined P2P_SUPPORT

    #ifdef RW_SUPPORT
    /* Register callback for reception of NDEF message from remote cards */
    RW_NDEF_RegisterPullCallback(*NdefPull_Cb);
    #endif // if defined RW_SUPPORT

    /* Open connection to NXPNCI device */
    DBG_PRINTF("1. Start: NxpNci_Connect\r\n");
   if (NxpNci_Connect() == NFC_ERROR) {
        DBG_PRINTF("Error: cannot connect to NXPNCI device\r\n");
        /* Turn On the Error LED */
        LED_Red_Write(LED_ON);

        return;
    }

    DBG_PRINTF("2. Start: NxpNci_ConfigureSettings\r\n");
    if (NxpNci_ConfigureSettings() == NFC_ERROR) {
        DBG_PRINTF("Error: cannot configure NXPNCI settings\r\n");
        /* Turn On the Error LED */
        LED_Red_Write(LED_ON);
        return;
    }

    DBG_PRINTF("3. Start: NxpNci_ConfigureMode\r\n");
    if (NxpNci_ConfigureMode(mode) == NFC_ERROR)
    {
        DBG_PRINTF("Error: cannot configure NXPNCI\r\n");
        /* Turn On the Error LED */
        LED_Red_Write(LED_ON);
        return;
    }

    /* Start Discovery */
    DBG_PRINTF("4. Start: NxpNci_StartDiscovery\r\n");
    if (NxpNci_StartDiscovery(DiscoveryTechnologies,sizeof(DiscoveryTechnologies)) != NFC_SUCCESS)
    {
        DBG_PRINTF("Error: cannot start discovery\r\n");
        /* Turn On the Error LED */
        LED_Red_Write(LED_ON);
        return;
    }

    DBG_PRINTF("5. Waiting...\r\n");

    while(1)
    {
        if (VcardMode) WaitFor_UART_VcardToken();
        
        if (VcardMode == 2) DBG_PRINTF("\r\nWAITING FOR MIFARE CARD DISCOVERY\r\n");
        else DBG_PRINTF("\r\nWAITING FOR DEVICE DISCOVERY\r\n");
        //CyDelay(5);

        /* Wait until a peer is discovered */
        while(NxpNci_WaitForDiscoveryNotification(&RfInterface) != NFC_SUCCESS);

    #ifdef CARDEMU_SUPPORT
        /* Is activated from remote T4T ? */
        if ((RfInterface.Interface == INTF_ISODEP) && ((RfInterface.ModeTech & MODE_MASK) == MODE_LISTEN))
        {
            DBG_PRINTF(" - LISTEN MODE: Activated from remote Reader\r\n");
    #ifndef CARDEMU_RAW_EXCHANGE
            NxpNci_ProcessCardMode(RfInterface);
    #else
            PICC_ISO14443_4_scenario();
    #endif
            DBG_PRINTF("READER DISCONNECTED\r\n");
        }
        else
    #endif

    #ifdef P2P_SUPPORT
        /* Is P2P discovery ? */
        if (RfInterface.Interface == INTF_NFCDEP)
        {
            /* Turn On the Amber Read OK LED */
            LED_Green_Write(LED_ON);
            LED_Red_Write(LED_ON);
            if ((RfInterface.ModeTech & MODE_LISTEN) == MODE_LISTEN) DBG_PRINTF(" - P2P TARGET MODE: Activated from remote Initiator\r\n");
            else DBG_PRINTF(" - P2P INITIATOR MODE: Remote Target activated\r\n");

            /* Process with SNEP for NDEF exchange */
            NxpNci_ProcessP2pMode(RfInterface);

            DBG_PRINTF("PEER LOST\r\n");
            /* Turn On the Amber Read OK LED */
            LED_Green_Write(LED_OFF);
            LED_Red_Write(LED_OFF);
            
            if (activateBLE) {
                DBG_PRINTF(" >> Entering BLE mode...\r\n");
                
                // WE NOW ENTER BLE MODE UNTIL DISCONNECTED
                // =========================================
                /* Infinite loop until activateBLE is false again*/
                while(1)
                {
                    /* Process pending BLE events */
                    CyBle_ProcessEvents();
                    
                    if (!activateBLE) break;
                    
                }
            }
            
        }
        else
    #endif // if defined P2P_SUPPORT
    #ifdef RW_SUPPORT
        if ((RfInterface.ModeTech & MODE_MASK) == MODE_POLL)
        {
            task_nfc_reader(RfInterface);
        }
        else
    #endif // if defined RW_SUPPORT
        {
            DBG_PRINTF("WRONG DISCOVERY\r\n");
        }
        
        // Check the WiFi Module just in case status change
        // If we've just transferred wifi data we need to loop a couple of times
        // If we have a VcardMode = 1 then we need to check WiFI UART for a response
        while (1) {
            if (!Check_UART_OK()) {
                if (!WiFiModuleMode) {
                    DBG_PRINTF(" --- UART Module rebooted...\r\n");
                    WiFiModuleMode = Establish_UART_Comms();
                }
                if (WiFiModuleMode == 2) {
                    DBG_PRINTF(" --- UART Module communicating again... waiting for WiFi status...\r\n");
                    DBG_PRINTF("\r\n -- checking WIFI connection status\r\n");
                    
                    WiFiModuleMode = Establish_WIFI_Comms();
                    
                    if (!WiFiModuleMode) {
                        DBG_PRINTF(" --- Nothing received about WiFi status...\r\n");
                    }
                }
                if (WiFiModuleMode == 3) {
                    DBG_PRINTF(" --- WiFi Module requires credentials...\r\n");
                }
                else if (WiFiModuleMode == 4) {
                    if (WiFiDataTransferred) WiFiDataTransferred = false;
                    DBG_PRINTF(" --- WiFi Module connected... waiting for vcard...\r\n");
                    // Clear the UART buffer
                    UART_WIFI_SpiUartClearRxBuffer();
                    
                }
            }
            if (WiFiModuleMode != 3 || !WiFiDataTransferred) break;
        }
    }
}


/*******************************************************************************
* Function Name: main()
********************************************************************************
* Summary:
*  Main function for the project.
*
* Theory:
*  The function starts UART, I2C and interrupt components.
*  Then it runs the function routine nfc_task()
*
*******************************************************************************/
int main()
{

    // Then start I2C SCB - this invokes I2CM_Init() and I2CM_Enable()
    /* Change SCL and SDA pins drive mode to Resistive Pull Up as the PN7150 arduino shield does not include any*/
    NXPNCI_I2CM_scl_SetDriveMode(NXPNCI_I2CM_scl_DM_RES_UP);
    NXPNCI_I2CM_sda_SetDriveMode(NXPNCI_I2CM_sda_DM_RES_UP);    
        
    // BLE Variables
    CYBLE_API_RESULT_T apiResult;
    CYBLE_STACK_LIB_VERSION_T stackVersion;

    LED_Red_Write(LED_ON);     /* Turn on Error LED to indicate no WiFi / UART */
    LED_Green_Write(LED_OFF);     /* Clear Read OK LED */
    LED_Blue_Write(LED_OFF);     /* Clear BLE comms LED */

#if(INTERRUPT_CODE_ENABLED == ENABLED)
{
    isr_rx_StartEx(RxIsr);
    
    /* Configure IRQ pin so that it can handle the wakeup if NFC card is presented*/
    /* Sets up the GPIO interrupt and enables it */
    isr_IRQ_StartEx(NxpNci_PinIRQ_Handler);
}    
#endif /* INTERRUPT_CODE_ENABLED == ENABLED */
    
    CyGlobalIntEnable;      /* Enable global interrupts. */

    /* Start UART communication component for Debugging*/
    UART_DEBUG_Start();
    DBG_PRINTF("\r\n PN7150 Driver Demo using PSoC 4 BLE Pioneer Kit\r\n");
    
    /* Start CYBLE component and register generic event handler */
    apiResult = CyBle_Start(BLEStackEventHandler);
    if(apiResult != CYBLE_ERROR_OK)
    {
        DBG_PRINTF("CyBle_Start API Error: %d \r\n", apiResult);
    }
    /* For info purposes only get BLE Library Stack Version */
    apiResult = CyBle_GetStackLibraryVersion(&stackVersion);
    if(apiResult != CYBLE_ERROR_OK)
    {
        DBG_PRINTF("CyBle_GetStackLibraryVersion API Error: %d \r\n", apiResult);
    }
    else
    { 
         DBG_PRINTF(" --- BLE Stack Version: %d.%d.%d.%d \r\n", stackVersion.majorVersion, 
            stackVersion.minorVersion, stackVersion.patch, stackVersion.buildNumber);
    }
    
    DBG_PRINTF(" --- BLE IpBlock Version: %5.5lx, stack RAM: %d \r\n", CyBLE_GetIpBlockVersion(), CYBLE_STACK_RAM_SIZE);
    
    /* Start UART communication component for WiFi module*/
    UART_WIFI_Start();
    CyDelay(2);
    
    DBG_PRINTF("\r\n -- checking if we have UART comms with WIFI module\r\n");

    WiFiModuleMode = Establish_UART_Comms();
    if (!WiFiModuleMode) {
        DBG_PRINTF(" --- UART Module not available...\r\n");
    }
    else if (WiFiModuleMode == 1) {
        DBG_PRINTF(" --- Received first response from UART...\r\n");
    }
    else if (WiFiModuleMode == 2) {
        DBG_PRINTF(" --- UART Module communicating... waiting for WiFi status...\r\n");
        
        DBG_PRINTF("\r\n -- checking WIFI connection status\r\n");
        
        WiFiModuleMode = Establish_WIFI_Comms();
        
        if (!WiFiModuleMode) {
            DBG_PRINTF(" --- Nothing received about WiFi status...\r\n");
        }
        else if (WiFiModuleMode == 3) {
            DBG_PRINTF(" --- WiFi Module requires credentials...\r\n");
        }
        else if (WiFiModuleMode == 4) {
            DBG_PRINTF(" --- WiFi Module connected... waiting for vcard...\r\n");
        }
        
    }
       
    if (WiFiModuleMode > 2) {
        
        NXPNCI_I2CM_Start();
        
        DBG_PRINTF("\r\n Present NFC Phone or Card to learn more...\r\n");

        CyDelay(100);

        // Call the PN7150 NFC task handler
        task_nfc();
    }
}

/* [] END OF FILE */
