/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <ble.h>

/***************************************
*        Global BLE Variables
***************************************/

extern uint8_t VcardMode;                  // We set this to say we have sent off a Vcard

/* Array to store a Vcard Data Field */
uint8 VcardFieldData[VDAT_CHAR_DATA_LEN] = {'\0'};
uint8 VcardRespData[3] = {'\0'};

CYBLE_CONN_HANDLE_T  connectionHandle;

/* Status flag for the Stack Busy state. This flag is used to notify the application 
* whether there is stack buffer free to push more data or not */
uint8 StackBusyStatus = 0;

uint16 Vcardcntr = 0;

_Bool VcardRecd = false;

/* Local variable to store the current CCCD value */
uint8 VDatCCCDvalue[CCCD_DATA_LEN];

/* Handle value to update the CCCD */
CYBLE_GATT_HANDLE_VALUE_PAIR_T VDatNotificationCCCDhandle;


/*******************************************************************************
* Function Name: BLEStackEventHandler
********************************************************************************
*
* Summary:
*  This is an event callback function to receive events from the CYBLE Component.
*
* Parameters:
*  uint8 event:       Event from the CYBLE component.
*  void* eventParams: A structure instance for corresponding event type. The
*                     list of events structure is described in the component
*                     datasheet.
*
* Return:
*  None
*
*******************************************************************************/

void BLEStackEventHandler(uint32 event, void *eventParam)
{
    CYBLE_API_RESULT_T apiResult;
    CYBLE_GAP_BD_ADDR_T localBLEAddr;
    
	/* Local variable to store the data received as part of the Write request events */
	CYBLE_GATTS_WRITE_REQ_PARAM_T *wrReqParam;

    uint8 i8;
    uint16 i16;

    extern _Bool activateBLE;
    
    switch(event)
    {
    /**********************************************************
    *                       General Events
    ***********************************************************/
    case CYBLE_EVT_STACK_ON: /* This event is received when the component is Started */
        DBG_PRINTF("[%lx] Bluetooth On. Device address is: ", event);
        for(i8 = CYBLE_GAP_BD_ADDR_SIZE; i8 > 0u; i8--)
        {
            DBG_PRINTF("%2.2X", localBLEAddr.bdAddr[i8-1]);
        }
        DBG_PRINTF("\r\n");

        /* Enter discoverable mode so that the remote Client could find the device. */
        apiResult = CyBle_GappStartAdvertisement(CYBLE_ADVERTISING_FAST);

        if(apiResult != CYBLE_ERROR_OK)
        {
            DBG_PRINTF("StartAdvertisement API Error: %d \r\n", apiResult);
        }
        
        break;

    case CYBLE_EVT_TIMEOUT:
        /* Possible timeout event parameter values:
        * CYBLE_GAP_ADV_MODE_TO -> GAP limited discoverable mode timeout;
        * CYBLE_GAP_AUTH_TO -> GAP pairing process timeout.
        */
        if(CYBLE_GAP_ADV_MODE_TO == *(uint8 *) eventParam)
        {
            DBG_PRINTF("Advertisement timeout occurred. Advertisement will be disabled.\r\n");
        }
        else
        {
            DBG_PRINTF("Timeout occurred.\r\n");
        }
        break;

    case CYBLE_EVT_HARDWARE_ERROR:    /* This event indicates that some internal HW error has occurred. */
        DBG_PRINTF("Hardware Error \r\n");
        break;

    case CYBLE_EVT_HCI_STATUS:
        DBG_PRINTF("HCI Error. Error code is %x.\r\n", *(uint8 *) eventParam);
        break;

    /**********************************************************
    *                       GAP Events
    ***********************************************************/
    case CYBLE_EVT_GAPP_ADVERTISEMENT_START_STOP:
        if(CyBle_GetState() == CYBLE_STATE_DISCONNECTED)
        {
            DBG_PRINTF("[%lx]  >>> BLE Disconnected \r\n", event);
            LED_Blue_Write(LED_OFF);
            activateBLE = false;
            DBG_PRINTF(" -- Returning to NFC mode...\r\n");
        }    
        break;

    case CYBLE_EVT_GAP_DEVICE_CONNECTED:
        DBG_PRINTF("[%lx] CYBLE_EVT_GAP_DEVICE_CONNECTED: %d \r\n", event, connectionHandle.bdHandle);
        LED_Blue_Write(LED_ON);
        // Clear the data from VcardFieldData
        memset(VcardFieldData, '\0', VDAT_CHAR_DATA_LEN);
        Vcardcntr = 0;
        VcardRecd = false;
        break;

    case CYBLE_EVT_GAP_DEVICE_DISCONNECTED:
        DBG_PRINTF("[%lx] CYBLE_EVT_GAP_DEVICE_DISCONNECTED\r\n", event);
        LED_Blue_Write(LED_OFF);
        activateBLE = false;
        DBG_PRINTF(" -- Returning to NFC mode...\r\n");
        break;

    /**********************************************************
    *                       GATT Events
    ***********************************************************/
    case CYBLE_EVT_GATT_CONNECT_IND:
        /* GATT connection was established */
        connectionHandle = *(CYBLE_CONN_HANDLE_T *) eventParam;
        DBG_PRINTF("[%lx] CYBLE_EVT_GATT_CONNECT_IND: %x\r\n", event, connectionHandle.attId);
        break;

    case CYBLE_EVT_GATT_DISCONNECT_IND:
        /* GATT connection was disabled */
        DBG_PRINTF("[%lx] CYBLE_EVT_GATT_DISCONNECT_IND:\r\n", event);
        connectionHandle.attId = 0u;

        break;

    case CYBLE_EVT_GATTS_XCNHG_MTU_REQ:
        break;

    case CYBLE_EVT_GATTS_INDICATION_ENABLED:
        break;

    case CYBLE_EVT_GATTC_READ_BY_TYPE_RSP:
        {
            CYBLE_GATTC_GRP_ATTR_DATA_LIST_T *locAttrData;
            
            locAttrData = &(*(CYBLE_GATTC_READ_BY_GRP_RSP_PARAM_T *)eventParam).attrData;
            
            DBG_PRINTF("[%lx] EVT_GATT_READ_BY_TYPE_RSP len=%x, value: ", event, locAttrData->attrLen);
            for(i8 = 0u; i8 < locAttrData->attrLen; i8++)
            { 
                DBG_PRINTF("%2.2x ",*(uint8 *)(locAttrData->attrValue + i8));
            }
            DBG_PRINTF("\r\n");
        }
        break;

        case CYBLE_EVT_GATTS_READ_CHAR_VAL_ACCESS_REQ:
        /* Triggered on server side when client sends read request and when
        * characteristic has CYBLE_GATT_DB_ATTR_CHAR_VAL_RD_EVENT property set.
        * This event could be ignored by application unless it need to response
        * by error response which needs to be set in gattErrorCode field of
        * event parameter. */
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTS_READ_CHAR_VAL_ACCESS_REQ: handle: %x \r\n", event, 
            ((CYBLE_GATTS_CHAR_VAL_READ_REQ_T *)eventParam)->attrHandle);
        break;

    case CYBLE_EVT_GATTS_WRITE_REQ:
		/* This event is received when Central device sends a Write command on an Attribute */
        wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
        /*
        DBG_PRINTF("Data Received: len %d | act len %d | %s", 
            wrReqParam->handleValPair.value.len,
            wrReqParam->handleValPair.value.actualLen,
            wrReqParam->handleValPair.value.val );
        */
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTS_WRITE_REQ - %x\r\n", event, wrReqParam->handleValPair.attrHandle);
		if(CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE == wrReqParam->handleValPair.attrHandle)
		{
			/* Extract the Write value sent by the Client/App for the CCCD */
            if(wrReqParam->handleValPair.value.val[CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX] == true) {
                DBG_PRINTF(">> CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX - true\r\n");
                //rgbledNotifications = TRUE;
            }
            else if(wrReqParam->handleValPair.value.val[CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX] == false) {
                DBG_PRINTF(">> CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_INDEX - true\r\n");
                //rgbledNotifications = FALSE;
            }
            
    		/* Update CCCD handle with notification status data*/
    		VDatNotificationCCCDhandle.attrHandle = CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESC_HANDLE;
    		VDatNotificationCCCDhandle.value.val = VDatCCCDvalue;
    		VDatNotificationCCCDhandle.value.len = CCCD_DATA_LEN;
            
    		/* Report data to BLE component for sending data when read by Central device */
    		CyBle_GattsWriteAttributeValue(&VDatNotificationCCCDhandle, 0, &connectionHandle, CYBLE_GATT_DB_PEER_INITIATED);
			
			/* Update the Vcard Notification attribute with new color coordinates */
            if (VcardRecd) {
                uint8 RespVal[] = {0x07};
    			SendVcardAckOverVcardNotification(RespVal, 1);
            }
            else {
                uint8 RespVal[] = {0x01};
    			SendVcardAckOverVcardNotification(RespVal, 1);
            }
            
        }
		/* Check if the returned handle is matching and extract the Vcard data*/
        if(CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CHAR_HANDLE == wrReqParam->handleValPair.attrHandle)
        {
			/* Extract the Write value sent by the Client/App for V Data characteristic */
            if ((Vcardcntr + wrReqParam->handleValPair.value.len) < VDAT_CHAR_DATA_LEN) {
                for (i8 = 0; i8 < wrReqParam->handleValPair.value.len; i8++) {
                    if (wrReqParam->handleValPair.value.val[i8] > 31 && wrReqParam->handleValPair.value.val[i8] < 127) {
                        VcardFieldData[Vcardcntr] = wrReqParam->handleValPair.value.val[i8];
                        Vcardcntr++;
                    }
                }
            }
            
            // This should be the last data segment -- let's check it's ok
            DBG_PRINTF("Vcard Data Length: %u\r\n", Vcardcntr);
            VcardRecd = true;
            for (i16 = 1; i16 < Vcardcntr; i16++) {
                if ((VcardFieldData[i16-1] == '^') && (VcardFieldData[i16] == '^')) {
                    DBG_PRINTF("\r");
                    VcardFieldData[i16-1] = '\r';
                }
                else if ((VcardFieldData[i16-1] == '^') && (VcardFieldData[i16] != '^')) {
                    DBG_PRINTF("\n");
                    VcardFieldData[i16-1] = '\n';
                }
                else {
                    DBG_PRINTF("%c", VcardFieldData[i16-1]);
                }
            }
            if (VcardFieldData[Vcardcntr-1] == '^') {
                DBG_PRINTF("\n");
                VcardFieldData[i16-1] = '\n';
            }
            else {
                DBG_PRINTF("%c", VcardFieldData[Vcardcntr-1]);
            }
            DBG_PRINTF("\r\n");
            // Now send via UART WIFI
            UART_WIFI_UartPutChar('v');
            UART_WIFI_UartPutCRLF(0x07);            // Hardcode the vCard byte that is used
            UART_WIFI_UartPutString((const char*)VcardFieldData);
            UART_WIFI_UartPutCRLF(0xC7);
            
            VcardMode = 1;                  // We set this to say we have sent off a Vcard
            
            // Now send a response back to BLE app
            uint8 RespVal[] = {0x07};
    		SendVcardAckOverVcardNotification(RespVal, 1);
        
        }
		
		/* Send the response to the write request received. */
		CyBle_GattsWriteRsp(connectionHandle);		
        break;
            
    case CYBLE_EVT_GATTC_WRITE_RSP:
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTC_WRITE_RSP\r\n", event);
        break;

    case CYBLE_EVT_GATTS_WRITE_CMD_REQ:
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTS_WRITE_CMD_REQ\r\n", event);
		/* This event is received when Central device sends a Write command on an Attribute */
        wrReqParam = (CYBLE_GATTS_WRITE_REQ_PARAM_T *) eventParam;
        /*
        DBG_PRINTF("Data Received: len %d | act len %d | %s", 
            wrReqParam->handleValPair.value.len,
            wrReqParam->handleValPair.value.actualLen,
            wrReqParam->handleValPair.value.val );
        */
        
        if ((Vcardcntr + wrReqParam->handleValPair.value.len) < VDAT_CHAR_DATA_LEN) {
            for (i8 = 0; i8 < wrReqParam->handleValPair.value.len; i8++) {
                if (wrReqParam->handleValPair.value.val[i8] > 31 && wrReqParam->handleValPair.value.val[i8] < 127) {
                    VcardFieldData[Vcardcntr] = wrReqParam->handleValPair.value.val[i8];
                    Vcardcntr++;
                }
            }
        }
        
        break;

    case CYBLE_EVT_GATTS_PREP_WRITE_REQ:
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTS_PREP_WRITE_REQ\r\n", event);
        break;

    case CYBLE_EVT_GATTS_EXEC_WRITE_REQ:
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTS_EXEC_WRITE_REQ\r\n", event);
        break;

    case CYBLE_EVT_GATTS_HANDLE_VALUE_CNF:
        DBG_PRINTF("[%lx] CYBLE_EVT_GATTS_HANDLE_VALUE_CNF\r\n", event); 
        //dataSendConfirmed = 1;
        break;
       
            
    /**********************************************************
    *                       Other Events
    ***********************************************************/
    case CYBLE_EVT_PENDING_FLASH_WRITE:
        /* Inform application that flash write is pending. Stack internal data 
        * structures are modified and require to be stored in Flash using 
        * CyBle_StoreBondingData() */
        DBG_PRINTF("CYBLE_EVT_PENDING_FLASH_WRITE\r\n");
        break;

	case CYBLE_EVT_STACK_BUSY_STATUS:
		/* This event is generated when the internal stack buffer is full and no more
		* data can be accepted or the stack has buffer available and can accept data.
		* This event is used by application to prevent pushing lot of data to stack. */
		
		/* Extract the present stack status */
        StackBusyStatus = * (uint8*)eventParam;
        DBG_PRINTF("CYBLE_EVT_STACK_BUSY_STATUS: %x\r\n", StackBusyStatus);
        
        break;

    default:
        DBG_PRINTF("OTHER event: %lx \r\n", event);
        break;
    }
}

/*******************************************************************************
* Function Name: SendVcardAckOverVcardNotification
********************************************************************************
* Summary:
*        Send a Vcard ack data to as BLE Notifications. This function updates
* the notification handle with some data and triggers the BLE component to send 
* notification
*
* Parameters:
*  uint8 *VcardData:	pointer to an array containing a response
*  uint8 len: length of the array
*
* Return:
*  void
*
*******************************************************************************/
void SendVcardAckOverVcardNotification(uint8 *VcardData, uint8 len)
{
	/* 'rgbLednotificationHandle' stores RGB LED notification data parameters */
	CYBLE_GATTS_HANDLE_VALUE_NTF_T 	vCardnotificationHandle;
	
	/* If stack is not busy, then send the notification */
	if(StackBusyStatus == CYBLE_STACK_STATE_FREE)
	{
		/* Update notification handle with CapSense slider data*/
		vCardnotificationHandle.attrHandle = CYBLE_THROUGHPUT_SERVICE_V_DATA_CHARACTERISTIC_CHAR_HANDLE;				
		vCardnotificationHandle.value.val = VcardData;
		vCardnotificationHandle.value.len = len;
		
		/* Send the updated handle as part of attribute for notifications */
		CyBle_GattsNotification(connectionHandle,&vCardnotificationHandle);
	}
}


/* [] END OF FILE */
