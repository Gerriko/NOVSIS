/***************************************************************************//**
* \file .h
* \version 4.0
*
* \brief
*  This private file provides constants and parameter values for the
*  SCB Component.
*  Please do not use this file or its content in your project.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_SCB_PVT_NXPNCI_I2CM_H)
#define CY_SCB_PVT_NXPNCI_I2CM_H

#include "NXPNCI_I2CM.h"


/***************************************
*     Private Function Prototypes
***************************************/

/* APIs to service INTR_I2C_EC register */
#define NXPNCI_I2CM_SetI2CExtClkInterruptMode(interruptMask) NXPNCI_I2CM_WRITE_INTR_I2C_EC_MASK(interruptMask)
#define NXPNCI_I2CM_ClearI2CExtClkInterruptSource(interruptMask) NXPNCI_I2CM_CLEAR_INTR_I2C_EC(interruptMask)
#define NXPNCI_I2CM_GetI2CExtClkInterruptSource()                (NXPNCI_I2CM_INTR_I2C_EC_REG)
#define NXPNCI_I2CM_GetI2CExtClkInterruptMode()                  (NXPNCI_I2CM_INTR_I2C_EC_MASK_REG)
#define NXPNCI_I2CM_GetI2CExtClkInterruptSourceMasked()          (NXPNCI_I2CM_INTR_I2C_EC_MASKED_REG)

#if (!NXPNCI_I2CM_CY_SCBIP_V1)
    /* APIs to service INTR_SPI_EC register */
    #define NXPNCI_I2CM_SetSpiExtClkInterruptMode(interruptMask) \
                                                                NXPNCI_I2CM_WRITE_INTR_SPI_EC_MASK(interruptMask)
    #define NXPNCI_I2CM_ClearSpiExtClkInterruptSource(interruptMask) \
                                                                NXPNCI_I2CM_CLEAR_INTR_SPI_EC(interruptMask)
    #define NXPNCI_I2CM_GetExtSpiClkInterruptSource()                 (NXPNCI_I2CM_INTR_SPI_EC_REG)
    #define NXPNCI_I2CM_GetExtSpiClkInterruptMode()                   (NXPNCI_I2CM_INTR_SPI_EC_MASK_REG)
    #define NXPNCI_I2CM_GetExtSpiClkInterruptSourceMasked()           (NXPNCI_I2CM_INTR_SPI_EC_MASKED_REG)
#endif /* (!NXPNCI_I2CM_CY_SCBIP_V1) */

#if(NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG)
    extern void NXPNCI_I2CM_SetPins(uint32 mode, uint32 subMode, uint32 uartEnableMask);
#endif /* (NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG) */


/***************************************
*     Vars with External Linkage
***************************************/

#if (NXPNCI_I2CM_SCB_IRQ_INTERNAL)
#if !defined (CY_REMOVE_NXPNCI_I2CM_CUSTOM_INTR_HANDLER)
    extern cyisraddress NXPNCI_I2CM_customIntrHandler;
#endif /* !defined (CY_REMOVE_NXPNCI_I2CM_CUSTOM_INTR_HANDLER) */
#endif /* (NXPNCI_I2CM_SCB_IRQ_INTERNAL) */

extern NXPNCI_I2CM_BACKUP_STRUCT NXPNCI_I2CM_backup;

#if(NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Common configuration variables */
    extern uint8 NXPNCI_I2CM_scbMode;
    extern uint8 NXPNCI_I2CM_scbEnableWake;
    extern uint8 NXPNCI_I2CM_scbEnableIntr;

    /* I2C configuration variables */
    extern uint8 NXPNCI_I2CM_mode;
    extern uint8 NXPNCI_I2CM_acceptAddr;

    /* SPI/UART configuration variables */
    extern volatile uint8 * NXPNCI_I2CM_rxBuffer;
    extern uint8   NXPNCI_I2CM_rxDataBits;
    extern uint32  NXPNCI_I2CM_rxBufferSize;

    extern volatile uint8 * NXPNCI_I2CM_txBuffer;
    extern uint8   NXPNCI_I2CM_txDataBits;
    extern uint32  NXPNCI_I2CM_txBufferSize;

    /* EZI2C configuration variables */
    extern uint8 NXPNCI_I2CM_numberOfAddr;
    extern uint8 NXPNCI_I2CM_subAddrSize;
#endif /* (NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG) */

#if (! (NXPNCI_I2CM_SCB_MODE_I2C_CONST_CFG || \
        NXPNCI_I2CM_SCB_MODE_EZI2C_CONST_CFG))
    extern uint16 NXPNCI_I2CM_IntrTxMask;
#endif /* (! (NXPNCI_I2CM_SCB_MODE_I2C_CONST_CFG || \
              NXPNCI_I2CM_SCB_MODE_EZI2C_CONST_CFG)) */


/***************************************
*        Conditional Macro
****************************************/

#if(NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG)
    /* Defines run time operation mode */
    #define NXPNCI_I2CM_SCB_MODE_I2C_RUNTM_CFG     (NXPNCI_I2CM_SCB_MODE_I2C      == NXPNCI_I2CM_scbMode)
    #define NXPNCI_I2CM_SCB_MODE_SPI_RUNTM_CFG     (NXPNCI_I2CM_SCB_MODE_SPI      == NXPNCI_I2CM_scbMode)
    #define NXPNCI_I2CM_SCB_MODE_UART_RUNTM_CFG    (NXPNCI_I2CM_SCB_MODE_UART     == NXPNCI_I2CM_scbMode)
    #define NXPNCI_I2CM_SCB_MODE_EZI2C_RUNTM_CFG   (NXPNCI_I2CM_SCB_MODE_EZI2C    == NXPNCI_I2CM_scbMode)
    #define NXPNCI_I2CM_SCB_MODE_UNCONFIG_RUNTM_CFG \
                                                        (NXPNCI_I2CM_SCB_MODE_UNCONFIG == NXPNCI_I2CM_scbMode)

    /* Defines wakeup enable */
    #define NXPNCI_I2CM_SCB_WAKE_ENABLE_CHECK       (0u != NXPNCI_I2CM_scbEnableWake)
#endif /* (NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG) */

/* Defines maximum number of SCB pins */
#if (!NXPNCI_I2CM_CY_SCBIP_V1)
    #define NXPNCI_I2CM_SCB_PINS_NUMBER    (7u)
#else
    #define NXPNCI_I2CM_SCB_PINS_NUMBER    (2u)
#endif /* (!NXPNCI_I2CM_CY_SCBIP_V1) */

#endif /* (CY_SCB_PVT_NXPNCI_I2CM_H) */


/* [] END OF FILE */
