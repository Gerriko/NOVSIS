/***************************************************************************//**
* \file NXPNCI_I2CM_PM.c
* \version 4.0
*
* \brief
*  This file provides the source code to the Power Management support for
*  the SCB Component.
*
* Note:
*
********************************************************************************
* \copyright
* Copyright 2013-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "NXPNCI_I2CM.h"
#include "NXPNCI_I2CM_PVT.h"

#if(NXPNCI_I2CM_SCB_MODE_I2C_INC)
    #include "NXPNCI_I2CM_I2C_PVT.h"
#endif /* (NXPNCI_I2CM_SCB_MODE_I2C_INC) */

#if(NXPNCI_I2CM_SCB_MODE_EZI2C_INC)
    #include "NXPNCI_I2CM_EZI2C_PVT.h"
#endif /* (NXPNCI_I2CM_SCB_MODE_EZI2C_INC) */

#if(NXPNCI_I2CM_SCB_MODE_SPI_INC || NXPNCI_I2CM_SCB_MODE_UART_INC)
    #include "NXPNCI_I2CM_SPI_UART_PVT.h"
#endif /* (NXPNCI_I2CM_SCB_MODE_SPI_INC || NXPNCI_I2CM_SCB_MODE_UART_INC) */


/***************************************
*   Backup Structure declaration
***************************************/

#if(NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG || \
   (NXPNCI_I2CM_SCB_MODE_I2C_CONST_CFG   && (!NXPNCI_I2CM_I2C_WAKE_ENABLE_CONST))   || \
   (NXPNCI_I2CM_SCB_MODE_EZI2C_CONST_CFG && (!NXPNCI_I2CM_EZI2C_WAKE_ENABLE_CONST)) || \
   (NXPNCI_I2CM_SCB_MODE_SPI_CONST_CFG   && (!NXPNCI_I2CM_SPI_WAKE_ENABLE_CONST))   || \
   (NXPNCI_I2CM_SCB_MODE_UART_CONST_CFG  && (!NXPNCI_I2CM_UART_WAKE_ENABLE_CONST)))

    NXPNCI_I2CM_BACKUP_STRUCT NXPNCI_I2CM_backup =
    {
        0u, /* enableState */
    };
#endif


/*******************************************************************************
* Function Name: NXPNCI_I2CM_Sleep
****************************************************************************//**
*
*  Prepares the NXPNCI_I2CM component to enter Deep Sleep.
*  The “Enable wakeup from Deep Sleep Mode” selection has an influence on this 
*  function implementation:
*  - Checked: configures the component to be wakeup source from Deep Sleep.
*  - Unchecked: stores the current component state (enabled or disabled) and 
*    disables the component. See SCB_Stop() function for details about component 
*    disabling.
*
*  Call the NXPNCI_I2CM_Sleep() function before calling the 
*  CyPmSysDeepSleep() function. 
*  Refer to the PSoC Creator System Reference Guide for more information about 
*  power management functions and Low power section of this document for the 
*  selected mode.
*
*  This function should not be called before entering Sleep.
*
*******************************************************************************/
void NXPNCI_I2CM_Sleep(void)
{
#if(NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG)

    if(NXPNCI_I2CM_SCB_WAKE_ENABLE_CHECK)
    {
        if(NXPNCI_I2CM_SCB_MODE_I2C_RUNTM_CFG)
        {
            NXPNCI_I2CM_I2CSaveConfig();
        }
        else if(NXPNCI_I2CM_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            NXPNCI_I2CM_EzI2CSaveConfig();
        }
    #if(!NXPNCI_I2CM_CY_SCBIP_V1)
        else if(NXPNCI_I2CM_SCB_MODE_SPI_RUNTM_CFG)
        {
            NXPNCI_I2CM_SpiSaveConfig();
        }
        else if(NXPNCI_I2CM_SCB_MODE_UART_RUNTM_CFG)
        {
            NXPNCI_I2CM_UartSaveConfig();
        }
    #endif /* (!NXPNCI_I2CM_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        NXPNCI_I2CM_backup.enableState = (uint8) NXPNCI_I2CM_GET_CTRL_ENABLED;

        if(0u != NXPNCI_I2CM_backup.enableState)
        {
            NXPNCI_I2CM_Stop();
        }
    }

#else

    #if (NXPNCI_I2CM_SCB_MODE_I2C_CONST_CFG && NXPNCI_I2CM_I2C_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_I2CSaveConfig();

    #elif (NXPNCI_I2CM_SCB_MODE_EZI2C_CONST_CFG && NXPNCI_I2CM_EZI2C_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_EzI2CSaveConfig();

    #elif (NXPNCI_I2CM_SCB_MODE_SPI_CONST_CFG && NXPNCI_I2CM_SPI_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_SpiSaveConfig();

    #elif (NXPNCI_I2CM_SCB_MODE_UART_CONST_CFG && NXPNCI_I2CM_UART_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_UartSaveConfig();

    #else

        NXPNCI_I2CM_backup.enableState = (uint8) NXPNCI_I2CM_GET_CTRL_ENABLED;

        if(0u != NXPNCI_I2CM_backup.enableState)
        {
            NXPNCI_I2CM_Stop();
        }

    #endif /* defined (NXPNCI_I2CM_SCB_MODE_I2C_CONST_CFG) && (NXPNCI_I2CM_I2C_WAKE_ENABLE_CONST) */

#endif /* (NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/*******************************************************************************
* Function Name: NXPNCI_I2CM_Wakeup
****************************************************************************//**
*
*  Prepares the NXPNCI_I2CM component for Active mode operation after 
*  Deep Sleep.
*  The “Enable wakeup from Deep Sleep Mode” selection has influence on this 
*  function implementation:
*  - Checked: restores the component Active mode configuration.
*  - Unchecked: enables the component if it was enabled before enter Deep Sleep.
*
*  This function should not be called after exiting Sleep.
*
*  \sideeffect
*   Calling the NXPNCI_I2CM_Wakeup() function without first calling the 
*   NXPNCI_I2CM_Sleep() function may produce unexpected behavior.
*
*******************************************************************************/
void NXPNCI_I2CM_Wakeup(void)
{
#if(NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG)

    if(NXPNCI_I2CM_SCB_WAKE_ENABLE_CHECK)
    {
        if(NXPNCI_I2CM_SCB_MODE_I2C_RUNTM_CFG)
        {
            NXPNCI_I2CM_I2CRestoreConfig();
        }
        else if(NXPNCI_I2CM_SCB_MODE_EZI2C_RUNTM_CFG)
        {
            NXPNCI_I2CM_EzI2CRestoreConfig();
        }
    #if(!NXPNCI_I2CM_CY_SCBIP_V1)
        else if(NXPNCI_I2CM_SCB_MODE_SPI_RUNTM_CFG)
        {
            NXPNCI_I2CM_SpiRestoreConfig();
        }
        else if(NXPNCI_I2CM_SCB_MODE_UART_RUNTM_CFG)
        {
            NXPNCI_I2CM_UartRestoreConfig();
        }
    #endif /* (!NXPNCI_I2CM_CY_SCBIP_V1) */
        else
        {
            /* Unknown mode */
        }
    }
    else
    {
        if(0u != NXPNCI_I2CM_backup.enableState)
        {
            NXPNCI_I2CM_Enable();
        }
    }

#else

    #if (NXPNCI_I2CM_SCB_MODE_I2C_CONST_CFG  && NXPNCI_I2CM_I2C_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_I2CRestoreConfig();

    #elif (NXPNCI_I2CM_SCB_MODE_EZI2C_CONST_CFG && NXPNCI_I2CM_EZI2C_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_EzI2CRestoreConfig();

    #elif (NXPNCI_I2CM_SCB_MODE_SPI_CONST_CFG && NXPNCI_I2CM_SPI_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_SpiRestoreConfig();

    #elif (NXPNCI_I2CM_SCB_MODE_UART_CONST_CFG && NXPNCI_I2CM_UART_WAKE_ENABLE_CONST)
        NXPNCI_I2CM_UartRestoreConfig();

    #else

        if(0u != NXPNCI_I2CM_backup.enableState)
        {
            NXPNCI_I2CM_Enable();
        }

    #endif /* (NXPNCI_I2CM_I2C_WAKE_ENABLE_CONST) */

#endif /* (NXPNCI_I2CM_SCB_MODE_UNCONFIG_CONST_CFG) */
}


/* [] END OF FILE */
