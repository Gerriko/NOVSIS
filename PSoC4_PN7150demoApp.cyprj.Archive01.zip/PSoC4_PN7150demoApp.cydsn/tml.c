/*
*         Copyright (c), NXP Semiconductors Caen / France
*
*                     (C)NXP Semiconductors
*       All rights are reserved. Reproduction in whole or in part is
*      prohibited without the written consent of the copyright owner.
*  NXP reserves the right to make changes without notice at any time.
* NXP makes no warranty, expressed, implied or statutory, including but
* not limited to any implied warranty of merchantability or fitness for any
*particular purpose, or that the use will not infringe any third party patent,
* copyright or trademark. NXP must not be liable for any loss or damage
*                          arising from its use.
*/

#include <tml.h>


/*******************************************************************************
* Global variables
*******************************************************************************/

typedef enum {ERROR = 0, SUCCESS = !ERROR} Status;



static Status tml_Init(void) {
    
    return SUCCESS;
    
}

static Status tml_DeInit(void) {
    Pin_VEN_Write(0u);       // Low
    return SUCCESS;
}


void tml_Reset(void) {
	/* Apply VEN reset */
    Pin_VEN_Write(1u);       // High
	CyDelay(10);
    Pin_VEN_Write(0u);       // Low
	CyDelay(10);                 // Min micro sec
    Pin_VEN_Write(1u);       // High
    CyDelay(40);                // Wait for reboot time (min 25 msec)
}

static uint32 I2C_WRITE(uint8_t *pBuff, uint32_t buffLen)
{

    (void) NXPNCI_I2CM_I2CMasterClearStatus();
    
    return NXPNCI_I2CM_I2CMasterWriteBuf(I2C_SLAVE_ADDR, pBuff, buffLen, NXPNCI_I2CM_I2C_MODE_COMPLETE_XFER);
    
}


static uint32 I2C_READ(uint8_t *pBuff, uint16_t buffLen)
{
    (void) NXPNCI_I2CM_I2CMasterClearStatus();

    return  NXPNCI_I2CM_I2CMasterReadBuf(I2C_SLAVE_ADDR, pBuff, buffLen, NXPNCI_I2CM_I2C_MODE_COMPLETE_XFER);
}

static _Bool checkMasterTransferStatus(void) {
    uint32_t masterStatus;
    _Bool     timeOutStatus;
    
    /* Timeout 100 msec (one unit is us) */
    uint32_t timeout = 1000000UL;
    /* Wait until master complete read transfer or time out has occured */
    do {
        masterStatus  = NXPNCI_I2CM_I2CMasterStatus();
        timeOutStatus = WaitOneUnit(&timeout);
        
    } while ((0UL != (masterStatus & NXPNCI_I2CM_I2C_MSTAT_XFER_INP)) && (timeOutStatus == false));
    
    if (timeOutStatus) {
        /* Timeout recovery */
        NXPNCI_I2CM_Stop();
        NXPNCI_I2CM_Enable();
    }
    else return (0u == (I2CMASTER_ERROR_MASK & masterStatus));
        
    return false;
}

static Status tml_Tx(uint8_t *pBuff, uint16_t buffLen) {
    
    uint32_t transferStatus = I2C_WRITE(pBuff, buffLen);
    
    if (transferStatus != NXPNCI_I2CM_I2C_MSTR_NO_ERROR) {
    	CyDelay(10);
        transferStatus = I2C_WRITE(pBuff, buffLen);
    	if(transferStatus != NXPNCI_I2CM_I2C_MSTR_NO_ERROR) return ERROR;
    }
    /* If I2C write started without errors, 
     * wait until I2C Master completes write transfer */
    while (0u == (NXPNCI_I2CM_I2CMasterStatus() & NXPNCI_I2CM_I2C_MSTAT_WR_CMPLT)) {;}
    
    /* Report transfer status */
    if (0u == (NXPNCI_I2CM_I2CMasterStatus() & NXPNCI_I2CM_I2C_MSTAT_ERR_XFER))
    {
        /* Check if all bytes were written */
        if (NXPNCI_I2CM_I2CMasterGetWriteBufSize() == buffLen)
        {
            return SUCCESS;
        }
    }
    return ERROR;
}

static Status tml_Rx(uint8_t *pBuff, uint16_t buffLen, uint16_t *pBytesRead) {

    uint32_t transferStatus = I2C_READ(pBuff, 3);
    
    if (transferStatus == NXPNCI_I2CM_I2C_MSTR_NO_ERROR) {
        /* If I2C read started without errors, 
        / wait until master complete read transfer */
        while (0u == (NXPNCI_I2CM_I2CMasterStatus() & NXPNCI_I2CM_I2C_MSTAT_RD_CMPLT)) {;}
        /* Display transfer status */
        if (0u == (NXPNCI_I2CM_I2C_MSTAT_ERR_XFER & NXPNCI_I2CM_I2CMasterStatus())) {
            /* Check packet structure is correct */
        	if ((pBuff[2] + 3) <= buffLen) {
    			if (pBuff[2] > 0) {
                    transferStatus = I2C_READ(&pBuff[3], pBuff[2]);
    				if (transferStatus == NXPNCI_I2CM_I2C_MSTR_NO_ERROR) {
                        while (0u == (NXPNCI_I2CM_I2CMasterStatus() & NXPNCI_I2CM_I2C_MSTAT_RD_CMPLT)) {;}
                        if (0u == (NXPNCI_I2CM_I2C_MSTAT_ERR_XFER & NXPNCI_I2CM_I2CMasterStatus())) {
    					    *pBytesRead = pBuff[2] + 3;
                        }
                        else return ERROR;
    				}
    				else return ERROR;
    			} 
                else *pBytesRead = 3;
        	}
        }
    }
    else return ERROR;

	return SUCCESS;
}


static Status tml_WaitForRx(uint32_t timeout) {
	CyDelay(1);
	if (timeout == 0) {
		while ((Pin_IRQ_Read() == 0));
	} 
    else {
		uint32_t to = timeout;
		while ((Pin_IRQ_Read() == 0)) {
			CyDelay(10);
			to -= 10;
            //if (IRQtrig == 1) break;
			if (to <= 0) return ERROR;
		}
	}
    
	return SUCCESS;
}

void tml_Connect(void) {
	tml_Init();
	tml_Reset();
}

void tml_Disconnect(void) {
	tml_DeInit();
}

void tml_Send(uint8_t *pBuffer, uint16_t BufferLen, uint16_t *pBytesSent) {

	if(tml_Tx(pBuffer, BufferLen) == ERROR) *pBytesSent = 0;
	else *pBytesSent = BufferLen;

}

void tml_Receive(uint8_t *pBuffer, uint16_t BufferLen, uint16_t *pBytes, uint32_t timeout) {

	if (tml_WaitForRx(timeout) == ERROR) *pBytes = 0;
	else tml_Rx(pBuffer, BufferLen, pBytes);

}

/******************************************************************************
* Function Name: WaitOneUnit
****************************************************************************//**
*
* Waits for one unit before unblock code execution.
* Note If a timeout value is 0, this function does nothing and returns 0.
*
* \param timeout
* The pointer to a timeout value.
*
* \return
* Returns 0 if a timeout does not expire or the timeout mask.
*
*******************************************************************************/
_Bool WaitOneUnit(uint32_t *timeout)
{
    uint32_t status = false;

    /* If the timeout equal to 0. Ignore the timeout */
    if (*timeout > 0UL)
    {
        CyDelayUs(1);
        --(*timeout);

        if (0UL == *timeout)
        {
            status = true;
        }
    }

    return (status);
}

