/*******************************************************************************
* File Name: app_common.h
*
* Version 1.0
*
* Description:
*  Contains the function prototypes and constants for the example
*  project.
*
********************************************************************************
* Copyright (2018), Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(MAIN_H)
#define MAIN_H

#include <project.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#include <math.h>
    
#include "cytypes.h"

#define ENABLED                     (1u)
#define DISABLED                    (0u)

/***************************************
* Conditional Compilation Parameters
***************************************/
#define UART_PRINTF_ENABLED         ENABLED
#define INTERRUPT_CODE_ENABLED      ENABLED
    
//#define RW_NDEF_WRITING
//#define RW_RAW_EXCHANGE
//#define CARDEMU_RAW_EXCHANGE



/***************************************
*           API Constants
***************************************/
#define true                            (1u)
#define false                           (0u)
    
#if(CY_PSOC4)
    #define LED_ON                      (0u)
    #define LED_OFF                     (1u)
#else   /* PSoC 3/PSoC 5LP: The LED is connected to the GND instead of Vdd. */
    #define LED_ON                      (1u)
    #define LED_OFF                     (0u)
#endif /* (CY_PSOC4) */

/* PN7150 Constants */
#define IRQ_HIGH                        (1u)
#define IRQ_LOW                         (0u)
#define VEN_HIGH                        (1u)
#define VEN_LOW                         (0u)
   
/* I2C Constants */
#define I2CADDR_FOUND                   (0x01u)
#define I2CADDR_NOTFND                  (0x00u)
#define I2CBUFFER_SIZE                  (128u)
    
/* I2C slave address to communicate with */
#define I2C_GENCALL_ADDR                (0x00u)
#define I2C_SLAVE_ADDR                  (0x28u)
#define I2C_DEVICEID_ADDR               (0x7Cu)

/* Combine master error statuses in single mask */
#define I2CMASTER_ERROR_MASK            (NXPNCI_I2CM_I2C_NAK_DATA | NXPNCI_I2CM_I2C_NAK_ADDR    | \
                                        NXPNCI_I2CM_I2C_MSTR_ERR_ARB_LOST | NXPNCI_I2CM_I2C_MSTR_ERR_ABORT_START | \
                                        NXPNCI_I2CM_I2C_MSTR_ERR_BUS_ERR)    
/* Delays in milliseconds */
//#define CMD_TO_CMD_DELAY                (2000UL)

#define NXPNCI_TIMEOUT_INFINITE	        (0u)
#define NXPNCI_TIMEOUT_100MS		    (100UL)
#define NXPNCI_TIMEOUT_300MS		    (300UL)
#define NXPNCI_TIMEOUT_1S			    (1000UL)
#define NXPNCI_TIMEOUT_2S			    (2000UL)
    
#define NXPNCI_I2C_ADDR                 I2C_SLAVE_ADDR

/***************************************
*        Macros
***************************************/
#if (UART_PRINTF_ENABLED == ENABLED)
    #define DBG_PRINTF(...)          (printf(__VA_ARGS__))
#else
    #define DBG_PRINTF(...)
#endif /* (DEBUG_UART_ENABLED == ENABLED) */


#define B_TO_BM_PTRN "%c%c%c%c%c%c%c%c%c%c%c%c"
#define B_TO_B12(byte1,byte2)  \
  (byte1 & 0x80 ? '1' : '0'), \
  (byte1 & 0x40 ? '1' : '0'), \
  (byte1 & 0x20 ? '1' : '0'), \
  (byte1 & 0x10 ? '1' : '0'), \
  (byte1 & 0x08 ? '1' : '0'), \
  (byte1 & 0x04 ? '1' : '0'), \
  (byte1 & 0x02 ? '1' : '0'), \
  (byte1 & 0x01 ? '1' : '0'), \
  (byte2 & 0x80 ? '1' : '0'), \
  (byte2 & 0x40 ? '1' : '0'), \
  (byte2 & 0x20 ? '1' : '0'), \
  (byte2 & 0x10 ? '1' : '0')

#define B_TO_BP_PTRN "%c%c%c%c%c%c%c%c%c"
#define B_TO_B9(byte1,byte2)  \
  (byte1 & 0x08 ? '1' : '0'), \
  (byte1 & 0x04 ? '1' : '0'), \
  (byte1 & 0x02 ? '1' : '0'), \
  (byte1 & 0x01 ? '1' : '0'), \
  (byte2 & 0x80 ? '1' : '0'), \
  (byte2 & 0x40 ? '1' : '0'), \
  (byte2 & 0x20 ? '1' : '0'), \
  (byte2 & 0x10 ? '1' : '0'), \
  (byte2 & 0x08 ? '1' : '0')
    
#define B_TO_BR_PTRN "%c%c%c"
#define B_TO_B3(byte1)  \
  (byte1 & 0x04 ? '1' : '0'), \
  (byte1 & 0x02 ? '1' : '0'), \
  (byte1 & 0x01 ? '1' : '0')

#define print_buf(x,y,z)  {unsigned int loop; DBG_PRINTF(x); for(loop=0;loop<z;loop++) DBG_PRINTF("%.2x ", y[loop]); DBG_PRINTF("\r\n");}

#endif /* MAIN_H */

/* [] END OF FILE */
