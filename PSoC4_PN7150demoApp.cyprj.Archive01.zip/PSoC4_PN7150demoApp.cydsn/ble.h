/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include <app_common.h>

/***************************************
*          API Constants
***************************************/
#define DISCONNECTED                        (0u)
#define ADVERTISING                         (1u)
#define CONNECTED                           (2u)

#define BLINK_DELAY                         (90u)


/***************************Macro Declarations*******************************/

/* Read and write length of VCard data fields*/
#define VDAT_CHAR_DATA_LEN					(400u)
											
/* Client Characteristic Configuration descriptor data length. This is defined
* as per BLE spec. */
#define CCCD_DATA_LEN						(2u)


/***************************************
*        Function Prototypes
***************************************/
void BLEStackEventHandler(uint32 event, void * eventParam);
void SendVcardAckOverVcardNotification(uint8 *VcardData, uint8 len);



/* [] END OF FILE */
